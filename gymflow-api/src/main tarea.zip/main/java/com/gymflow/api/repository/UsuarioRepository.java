package com.gymflow.api.repository;

import com.gymflow.api.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Optional<Usuario> findByEmail(String email);

    boolean existsByEmail(String email);

    // Para editar: ¿otro usuario distinto ya usa este correo?
    boolean existsByEmailAndIdNot(String email, Long id);
}