package com.gymflow.api.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record UsuarioUpdateRequest(
        @NotBlank(message = "El nombre es obligatorio")
        @Size(max = 100, message = "El nombre no puede pasar de 100 caracteres")
        @Pattern(regexp = "^[\\p{L}][\\p{L}\\s.'’-]*$",
                message = "El nombre solo puede llevar letras, espacios, punto, guion y apóstrofo")
        String nombre,

        @NotBlank(message = "El correo es obligatorio")
        @Email(message = "El correo no tiene un formato válido")
        @Size(max = 150, message = "El correo no puede pasar de 150 caracteres")
        @Pattern(regexp = "^[^@\\s]+@[^@\\s]+\\.[^@\\s]{2,}$",
                message = "El correo debe tener un formato como nombre@dominio.com")
        String email,

        @Pattern(regexp = "^([0-9]{10})?$",
                message = "El teléfono debe tener exactamente 10 dígitos, solo números")
        String telefono,

        // Opcional: solo se cambia si se manda (vacío = no cambiar)
        @Pattern(regexp = "^$|^(?=.*[A-Za-z])(?=.*\\d)[\\x20-\\x7E]{8,72}$",
                message = "La contraseña debe tener de 8 a 72 caracteres, con al menos una letra y un número, sin acentos ni emojis")
        String password
) {
}